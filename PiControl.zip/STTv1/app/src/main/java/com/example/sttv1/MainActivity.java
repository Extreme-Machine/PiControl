package com.example.sttv1;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;

/*
Include
<uses-permission android:name="android.permission.INTERNET" />
in AndroidManifest.xml
 */
public class MainActivity extends AppCompatActivity {

    private String str,str_on="on",str_off="of off",str_door="door unlock open lock close",str_invalid="on off of";

    private String ip_str="192.168.0.101";
   /* private String str_one="one 1 light";
    private String str_two="two to 2 led";
    private String str_three="three 3 bulb";
    private String str_four="four 4 fan";*/
    private TextView textView,textView2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.textView);
        textView2 = (TextView) findViewById(R.id.textView2);
    }

    public void goRelay(View view3) {
        //Relay Activity
        if(view3.getId() == R.id.button3){
            Intent intentRelay = new Intent(MainActivity.this, relay.class);
            startActivity(intentRelay);
        }
    }


    public void startStream(View view4) {
        //Relay Activity
        if(view4.getId() == R.id.button4){
            Intent webPageIntent = new Intent(Intent.ACTION_VIEW);
            webPageIntent.setData(Uri.parse("http://192.168.0.101:8081"));
            try {
                startActivity(webPageIntent);
            } catch (ActivityNotFoundException ex) {
            }
        }
    }

    public void goHelp(View view2) {
                                                        //Help Activity
        if(view2.getId() == R.id.button2){
            Intent intentHelp = new Intent(MainActivity.this, help.class);
            startActivity(intentHelp);
        }
    }

    public void getInput(View view) {

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 10);
        } else {
            Toast.makeText(this, "Your Device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    textView.setText(result.get(0));
                    str=result.get(0);
                    scanText();
                }
                break;
        }
    }

    public void scanText(){

        if(str.toLowerCase().contains("on") ){

            if(str.toLowerCase().contains("one") || str.toLowerCase().contains("1") || str.toLowerCase().contains("light") ) {
                textView2.setText("Switch 1 ON");
                new gpio_request().execute("6&switch=1");
                Toast.makeText(getApplicationContext(),"Switch ON",Toast.LENGTH_SHORT).show();
            }
            else if(str.toLowerCase().contains("two") || str.toLowerCase().contains("2") || str.toLowerCase().contains("to")  || str.toLowerCase().contains("bulb") ) {
                textView2.setText("Switch 2 ON");
                new gpio_request().execute("13&switch=1");
                Toast.makeText(getApplicationContext(),"Switch ON",Toast.LENGTH_SHORT).show();
            }
            else if(str.toLowerCase().contains("three") || str.toLowerCase().contains("3") || str.toLowerCase().contains("led") ){
                textView2.setText("Switch 3 ON");
                new gpio_request().execute("19&switch=1");
                Toast.makeText(getApplicationContext(),"Switch ON",Toast.LENGTH_SHORT).show();
            }
            else if(str.toLowerCase().contains("four") || str.toLowerCase().contains("4") || str.toLowerCase().contains("fan")  ){
                textView2.setText("Switch  4 ON");
                new gpio_request().execute("26&switch=1");
                Toast.makeText(getApplicationContext(),"Switch ON",Toast.LENGTH_SHORT).show();
            }

            /*textView2.setText("Switch ON");
            new gpio_request().execute("6&switch=1");*/
        }

        else if(str.toLowerCase().contains("off") || str.toLowerCase().contains("of") ){

            if(str.toLowerCase().contains("one") || str.toLowerCase().contains("1") || str.toLowerCase().contains("light") ) {
                textView2.setText("Switch 1 OFF");
                new gpio_request().execute("6&switch=0");
                Toast.makeText(getApplicationContext(),"Switch OFF",Toast.LENGTH_SHORT).show();
            }
            else if(str.toLowerCase().contains("two") || str.toLowerCase().contains("2") || str.toLowerCase().contains("to")  || str.toLowerCase().contains("bulb") ) {
                textView2.setText("Switch 2 OFF");
                new gpio_request().execute("13&switch=0");
                Toast.makeText(getApplicationContext(),"Switch OFF",Toast.LENGTH_SHORT).show();
            }
            else if(str.toLowerCase().contains("three") || str.toLowerCase().contains("3") || str.toLowerCase().contains("led") ){
                textView2.setText("Switch 3 OFF");
                new gpio_request().execute("19&switch=0");
                Toast.makeText(getApplicationContext(),"Switch OFF",Toast.LENGTH_SHORT).show();
            }
            else if(str.toLowerCase().contains("four") || str.toLowerCase().contains("4") || str.toLowerCase().contains("fan")  ){
                textView2.setText("Switch  4 OFF");
                new gpio_request().execute("26&switch=0");
                Toast.makeText(getApplicationContext(),"Switch OFF",Toast.LENGTH_SHORT).show();
            }
        }

        else if(str.toLowerCase().contains("door")) {
            if(str.toLowerCase().contains("lock") || str.toLowerCase().contains("close")){
                //action
                textView2.setText("Door locked!");
                new gpio_lock().execute("lock=1");
                Toast.makeText(getApplicationContext(),"Door Locked",Toast.LENGTH_SHORT).show();
            }
            if(str.toLowerCase().contains("unlock") || str.toLowerCase().contains("open")){
                //action
                textView2.setText("Door unlocked!");
                new gpio_lock().execute("lock=0");
                Toast.makeText(getApplicationContext(),"Door Unlocked",Toast.LENGTH_SHORT).show();
            }

        }

        else{
            textView2.setText("Couldn't Recognize! Try again.");
        }

       /*else if( str.toLowerCase().contains("on") && (str.toLowerCase().contains("of") || str.toLowerCase().contains("off")) ) {
            textView2.setText("Couldn't recognize! Try again.");
        }*/

    }


    public class gpio_request extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                URL url = new URL("http://"+ip_str+"/gpioindex.php?pin="+ params[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder result = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null)
                    result.append(inputLine).append("\n");

                in.close();
                connection.disconnect();
                return result.toString();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class gpio_lock extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                URL url = new URL("http://"+ip_str+"/gpiolock.php?"+ params[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder result = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null)
                    result.append(inputLine).append("\n");

                in.close();
                connection.disconnect();
                return result.toString();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
