package com.example.sttv1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class help extends AppCompatActivity {


    private TextView textView4;
    private String str_help="Switching --->\n\nTurn on/off commands:\n\n1.Switch 1 :'Switch one on.' or 'Switch one off.'\n2.Switch 2 :'Switch two on.' or 'Switch two off.'\n3.Switch 3 :'Switch three on.' or 'Switch three off.'\n4.Switch 4 :'Switch four on.' or 'Switch four off.'\n\nDoor commands --->\n\n1.Unlock : 'Unlock Door.'\n2.Lock : 'Lock door.'\n\nIP address --->\n\nInput IP address of Raspberry Pi.\n";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        textView4 = (TextView) findViewById(R.id.textView4);
        textView4.setText(str_help);
    }
}
