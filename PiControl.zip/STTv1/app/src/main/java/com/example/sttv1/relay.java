package com.example.sttv1;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import static com.example.sttv1.R.id.iptext;

public class relay extends AppCompatActivity {

    public Button But,ButLock,ButUnlock;
    public EditText etip;
    public String ip_str;
    public TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relay);

        But = (Button)findViewById(R.id.subBut);
        ButLock = (Button)findViewById(R.id.buttonLock);
        ButUnlock = (Button)findViewById(R.id.buttonUnlock);
        text = (TextView)findViewById(R.id.textViewip);

        final Switch load1 = (Switch) findViewById(R.id.switch1);
        final Switch load2 = (Switch) findViewById(R.id.switch2);
        final Switch load3 = (Switch) findViewById(R.id.switch3);
        final Switch load4 = (Switch) findViewById(R.id.switch4);


        final SharedPreferences preferences = getPreferences(MODE_PRIVATE);

        //Retrieving values after resuming activity
        boolean Switch1 = preferences.getBoolean("Switch1", false);
        boolean Switch2 = preferences.getBoolean("Switch2", false);
        boolean Switch3 = preferences.getBoolean("Switch3", false);
        boolean Switch4 = preferences.getBoolean("Switch4", false);
        String ipaddr = preferences.getString("ipaddr",ip_str);

        //Setting values after resuming activity
        load1.setChecked(Switch1);
        load2.setChecked(Switch2);
        load3.setChecked(Switch3);
        load4.setChecked(Switch4);
        if(ipaddr == null)
        {
        }
        else {
            ip_str = ipaddr;
            text.setText("Pi's address: "+ip_str+"\n");
        }

        But.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etip=(EditText)findViewById(iptext);
                ip_str = etip.getText().toString();
                text.setText("Pi's address: "+ip_str+"\n");
                load1.setChecked(false);
                load2.setChecked(false);
                load3.setChecked(false);
                load4.setChecked(false);

                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("ipaddr",ip_str); // value to store
                editor.commit();

            }
        });

        ButLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new gpio_lock().execute("lock=1");
                Toast.makeText(getApplicationContext(),"Door Lock",Toast.LENGTH_SHORT).show();
            }
        });

        ButUnlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new gpio_lock().execute("lock=0");
                Toast.makeText(getApplicationContext(),"Door Unlock",Toast.LENGTH_SHORT).show();
            }
        });


        load1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    /* Switch is led 1 */
                    new gpio_request().execute("6&switch=1");
                    Toast.makeText(getApplicationContext(),"Switch ON",Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("Switch1", true); // value to store
                    editor.commit();

                } else {
                    new gpio_request().execute("6&switch=0");
                    Toast.makeText(getApplicationContext(),"Switch OFF",Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("Switch1", false); // value to store
                    editor.commit();

                }
            }
        });

        load2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    new gpio_request().execute("13&switch=1");
                    Toast.makeText(getApplicationContext(),"Switch ON",Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("Switch2", true); // value to store
                    editor.commit();

                } else {
                    new gpio_request().execute("13&switch=0");
                    Toast.makeText(getApplicationContext(),"Switch OFF",Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("Switch2", false); // value to store
                    editor.commit();

                }
            }
        });

        load3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    /* Switch is led 1 */
                    new gpio_request().execute("19&switch=1");
                    Toast.makeText(getApplicationContext(),"Switch ON",Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("Switch3", true); // value to store
                    editor.commit();

                } else {
                    new gpio_request().execute("19&switch=0");
                    Toast.makeText(getApplicationContext(),"Switch OFF",Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("Switch3", false); // value to store
                    editor.commit();

                }
            }
        });

        load4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    /* Switch is led 1 */
                    new gpio_request().execute("26&switch=1");
                    Toast.makeText(getApplicationContext(),"Switch ON",Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("Switch4", true); // value to store
                    editor.commit();

                } else {
                    new gpio_request().execute("26&switch=0");
                    Toast.makeText(getApplicationContext(),"Switch OFF",Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("Switch4", false); // value to store
                    editor.commit();

                }
            }
        });
    }




    public class gpio_request extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                URL url = new URL("http://"+ip_str+"/gpioindex.php?pin="+ params[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder result = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null)
                    result.append(inputLine).append("\n");

                in.close();
                connection.disconnect();
                return result.toString();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class gpio_lock extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                URL url = new URL("http://"+ip_str+"/gpiolock.php?"+ params[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder result = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null)
                    result.append(inputLine).append("\n");

                in.close();
                connection.disconnect();
                return result.toString();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
